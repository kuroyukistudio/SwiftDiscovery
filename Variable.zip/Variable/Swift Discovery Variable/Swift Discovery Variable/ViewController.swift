//
//  ViewController.swift
//  Swift Discovery Variable
//
//  Created by Leo on 13/06/2017.
//  Copyright © 2017 Leo. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {
    
    
    // Variable 
    var hi: String!
    var prenom: String = ""
    var age: Int = 0
    
    var solde: Int = 0
    var prix: Int = 0
    
    
    // Outlet
    @IBOutlet weak var outletPrenom: NSTextFieldCell!
    @IBOutlet weak var retourPrenom: NSTextFieldCell!
    
    @IBOutlet weak var outletAge: NSTextFieldCell!
    @IBOutlet weak var retourAge: NSTextFieldCell!
    
    @IBOutlet weak var outletSolde: NSTextField!
    @IBOutlet weak var outletPrix: NSTextField!
    
    
    //------------------------------------------------------------------------------------------------------------------//
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    //------------------------------------------------------------------------------------------------------------------//
    // Action Composition texte
    @IBAction func testPrenom(_ sender: Any) {
        
        prenom = outletPrenom.stringValue
        
        hi = "Bonjour mon prénom est " + prenom + "."
        
        retourPrenom.stringValue = hi
    }
    
    @IBAction func testAge(_ sender: Any) {
        
        age = Int(outletAge.stringValue)!
        
        hi = hi + " j'ai \(age) ans!"
        
        retourAge.stringValue = hi
    }
    
    //------------------------------------------------------------------------------------------------------------------//
    // Action Numerique
    @IBAction func testTransaction(_ sender: Any) {
        
        solde = Int(outletSolde.stringValue)!
        prix = Int(outletPrix.stringValue)!
        
        outletSolde.stringValue = "\(solde - prix)"
        
    }
    
}

