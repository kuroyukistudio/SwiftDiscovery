//: Playground - noun: a place where people can play

import Cocoa


// About Variable and Constant

// Variable, élément pouvant contenir des informations principalement text, numerique, booleen
// Par definition une variable et un élément qui peu changer de contenue avec le temps.
// Elle peu etre utiliser et modifié à de nombreuse reprise

// Contante, élément identique à la variable mais fixe, une fois defini aucune modification n'est possible


//Variable texte -----------------------------------------------------------------------------------------//

//Déclaration simple
var hi: String!


//Déclaration avec valeur
var bjr: String = "Bonjour"
var prenom: String = "Lucas"


//---------utilisation----------/

//Concatelation des variables texte
hi = bjr + " mon prénom est " + prenom + "."



//Variable numérique -------------------------------------------------------------------------------------//

//Déclaration simple
var solde: Int!
var prix: Int!

//Déclaration avec valeur
var age: Int = 23


//---------utilisation----------/

//Concatenation des variables texte et numerique
hi = hi + " j'ai \(age) ans!"


//Utilisation numerique
solde = 1486
prix = 149

//Calcul du nouveau solde
solde = solde - prix



//Variable booleene -------------------------------------------------------------------------------------//

//Déclaration simple
var test: Bool!


//Déclaration avec valeur
var status: Bool = true


